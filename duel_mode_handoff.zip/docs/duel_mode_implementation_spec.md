# Duel Mode Expansion — Implementation Specification

## Goal

Add three lightweight, ping-independent games to the existing Duel Mode:

- **Crown Duel**
- **Number Clash**
- **Bid War**

Rock Paper Scissors already exists and must continue working unchanged.

These games should reuse the existing lobby, matchmaking, player cards, avatars, ready-state logic, timers, networking, rematch flow, result screens, sounds, and design tokens wherever possible. Do not introduce a game engine or heavy frontend dependency. Keep the implementation web-native using the project's current HTML/CSS/JS or framework stack.

The games should feel like part of the existing Relay visual system: dark navy/purple background, blue player side, red opponent side, purple for special actions, gold/yellow for wins and primary CTAs, bold rounded panels, strong `VS` moments, short energetic transitions, and readable game cards.

---

# 1. Shared Multiplayer Rules

Every new duel must use a **commit → wait → reveal → resolve** model.

The server is authoritative. A player should never win because their request reached the server first.

For every hidden action:

1. The client submits an intent.
2. The server validates it.
3. The server stores it privately.
4. The submitting client receives `locked`.
5. The opponent receives only `opponent locked`.
6. Once both legal actions exist, the server resolves the round.
7. Both clients receive the reveal/result payload.

Never place an opponent's hidden card, number, sacrifice details, or bid in public room state before reveal.

Suggested shared lifecycle:

```text
LOBBY
→ MATCH READY
→ GAME INTRO
→ ROUND START
→ DECISION
→ LOCKED / WAITING
→ BOTH LOCKED
→ REVEAL
→ ROUND RESULT
→ NEXT ROUND
→ MATCH RESULT
→ REMATCH / DUEL MENU
```

Use the current Duel Mode timer if one exists. A default around 20 seconds per decision is appropriate.

Timeout defaults:

- Crown Duel strategy phase: `Play Normally`
- Crown Duel card selection: random legal remaining card
- Number Clash: random unused number
- Bid War: bid `0`

Reconnects must restore legal public state without leaking hidden opponent choices.

---

# 2. Shared UI Direction

Do not redesign the whole website.

Reuse the current Relay theme and shell. The game screens should feel like a more focused extension of the lobby, not a separate fantasy application.

Preferred visual language:

- dark navy/purple page background
- blue for the local player
- red for the opponent
- purple for neutral/special actions
- gold/yellow for wins, crowns, prizes, and main CTAs
- white high-contrast headings
- bold outlined cards
- rounded panels
- small lightning/confetti accents
- strong central `VS`
- large round indicator
- obvious lock/wait/reveal states

Crown Duel may use fantasy character art inside cards, but keep the surrounding UI modern and consistent with Relay.

Keep the interface DOM-based. Use CSS transforms, opacity, gradients, shadows, and short animations rather than canvas, Three.js, Phaser, PixiJS, video backgrounds, or a new animation framework.

Support keyboard interaction, visible focus states, reduced motion, and touch targets around 44px minimum.

---

# 3. CROWN DUEL

## Core Concept

Crown Duel is a **3-round hidden-card duel**.

Each player begins with five cards:

- King
- Knight
- Guard
- Assassin
- Peasant

Each card instance may be used once unless transformed through Royal Sacrifice.

Every different-card matchup must produce exactly one winner.

**Only the same card against itself causes a draw.**

Each won round gives **1 Crown**.

After three rounds, the player with more Crowns wins. A tied match enters Sudden Death.

---

## Crown Duel Matchups

### King

King defeats:

- Knight
- Guard
- Assassin

King loses to:

- Peasant

### Peasant

Peasant defeats:

- King

Peasant loses to:

- Knight
- Guard
- Assassin

### Knight

Knight defeats:

- Assassin
- Peasant

Knight loses to:

- Guard
- King

### Guard

Guard defeats:

- Knight
- Peasant

Guard loses to:

- Assassin
- King

### Assassin

Assassin defeats:

- Guard
- Peasant

Assassin loses to:

- Knight
- King

### Same-card rule

```text
King vs King = Draw
Knight vs Knight = Draw
Guard vs Guard = Draw
Assassin vs Assassin = Draw
Peasant vs Peasant = Draw
```

Both cards are consumed even when the round draws.

The easy tutorial wording should be:

> King beats all fighters. Peasant beats King. All fighters beat Peasant. Guard beats Knight, Knight beats Assassin, Assassin beats Guard.

---

## Royal Sacrifice

Each player may use **Royal Sacrifice once per match**.

The player:

1. sacrifices exactly two unused cards
2. selects one other unused card
3. transforms that third card into another character
4. may transform into Knight, Guard, Assassin, or Peasant
5. may never create a King

The sacrificed cards disappear permanently.

The transformed card remains playable.

Duplicates are legal.

Example:

```text
Remaining:
King
Knight
Guard
Assassin
Peasant

Sacrifice:
Knight
Guard

Transform:
Assassin → Peasant

New remaining hand:
King
Peasant
Peasant
```

The King may itself be sacrificed or transformed away. Once the original King is gone, Royal Sacrifice cannot recreate it.

This cost works cleanly with a three-round match:

```text
Before Round 1:
5 cards - 2 sacrificed = 3 playable cards

Before Round 2:
4 cards - 2 sacrificed = 2 playable cards

Before Round 3:
3 cards - 2 sacrificed = 1 playable card
```

So Royal Sacrifice can be used before any normal round without leaving the player unable to finish the match.

---

## Crown Duel Round Flow

Every round begins with a **Strategy Phase**.

Both players secretly choose either:

```text
PLAY_NORMALLY
```

or:

```text
ROYAL_SACRIFICE
```

Royal Sacrifice is only available if unused and enough legal cards remain.

Both strategy choices are committed before either is revealed.

After both submit, reveal only whether a sacrifice occurred.

Valid public messages:

```text
Neither player used Royal Sacrifice.
Opponent performed a Royal Sacrifice.
You performed a Royal Sacrifice.
Both players performed a Royal Sacrifice.
```

The opponent must **not** learn:

- which two cards were sacrificed
- which card was transformed
- what the transformed card became
- the exact post-sacrifice hand

After the strategy phase, both players choose one available combat card, lock in, wait, reveal simultaneously, resolve, award Crown if applicable, and consume both played cards.

---

## Crown Duel Sacrifice UI

Use a focused `Royal Sacrifice` screen or modal.

### Step 1

Select exactly two unused cards to destroy.

Use a destructive purple/red outline.

### Step 2

Select one different unused card as the transformation target.

Use a blue transformation outline.

### Step 3

Choose the new identity:

```text
Knight
Guard
Assassin
Peasant
```

Do not offer King.

Reject a no-op transformation where the selected card would become the same identity it already has.

### Step 4

Show confirmation:

```text
ROYAL SACRIFICE

2 cards will be permanently destroyed.
1 card will change identity.

Your opponent will know a sacrifice happened,
but will not know what changed.

[ CONFIRM SACRIFICE ]
[ CANCEL ]
```

After server confirmation, the sacrifice cannot be undone.

---

## Crown Duel State

A card needs an instance ID because duplicate identities may exist after transformation.

Conceptually:

```ts
type CrownCardType =
  | "king"
  | "knight"
  | "guard"
  | "assassin"
  | "peasant";

interface CrownCardInstance {
  id: string;
  originalType: CrownCardType;
  currentType: CrownCardType;
  status: "available" | "played" | "sacrificed";
}

interface CrownPlayerState {
  playerId: string;
  crowns: number;
  sacrificeUsed: boolean;
  cards: CrownCardInstance[];
  strategyChoice?: "normal" | "sacrifice";
  lockedCardId?: string;
}
```

Use a deterministic matchup map:

```ts
const defeats = {
  king: ["knight", "guard", "assassin"],
  peasant: ["king"],
  knight: ["assassin", "peasant"],
  guard: ["knight", "peasant"],
  assassin: ["guard", "peasant"],
};
```

Resolver:

```ts
function resolveCrownCards(a, b) {
  if (a === b) return "draw";
  return defeats[a].includes(b) ? "playerA" : "playerB";
}
```

Add tests for all 25 ordered pairings.

---

## Crown Duel Sudden Death

If the score is tied after Round 3:

- give both players a fresh standard five-card hand
- Royal Sacrifice does not reset if already used
- an unused Royal Sacrifice remains available
- play one round at a time
- first non-draw round wins the match
- same-card draws consume those two cards
- if all cards are exhausted through draws, refresh the standard hand and continue

Do not use randomness or a coin flip to choose the match winner.

---

## Crown Duel Screens

Implement:

### Intro / Matchmaking

Show:

- Crown Duel logo
- tagline: `Think. Sacrifice. Outsmart.`
- player and opponent panels
- `3 Rounds`
- `Royal Sacrifice: Once per match`
- `Draw: Same card only`
- Find Match / Invite Friend

### Strategy

Show:

- Round X of 3
- Crown score
- current hand
- used/sacrificed cards disabled
- compact card guide
- `Play Normally`
- `Royal Sacrifice`

### Sacrifice Announcement

Short transition:

```text
⚡ ROYAL SACRIFICE

Your opponent changed their hand.

The sacrifice is known.
The cards remain hidden.
```

### Card Selection

Large hand cards, central timer, lock button, opponent card backs.

### Reveal

Bring both cards into the center:

```text
ASSASSIN
VS
GUARD

ASSASSIN WINS
+1 CROWN
```

### Match Result

```text
CROWN DUEL

ALPHA WINS
2 - 1

[ PLAY AGAIN ]
[ DUEL MENU ]
```

---

# 4. NUMBER CLASH

## Core Concept

Each player receives the numbers:

```text
1 2 3 4 5 6 7 8 9
```

Each number can be played only once.

Both players secretly select one unused number.

Higher number wins the round.

Same number draws.

Both selected numbers are consumed regardless of outcome.

A win gives **1 point**.

The first player to **4 points** wins.

The match has up to **7 normal rounds**.

---

## Number Clash Strategy

Do not add extra powers or arithmetic in v1.

The depth comes from spending numbers efficiently.

Using `9` to beat `1` wins the current round, but the opponent traded their weakest number for your strongest.

The UI should make used and remaining numbers obvious.

---

## Number Clash State

Conceptually:

```ts
interface NumberClashPlayerState {
  playerId: string;
  score: number;
  availableNumbers: number[];
  usedNumbers: number[];
  lockedNumber?: number;
}
```

After every non-draw round:

```ts
if (player.score >= 4) finishMatch(player);
```

If Round 7 finishes without either player reaching four points:

- higher score wins
- equal score enters Sudden Death

---

## Number Clash Sudden Death

Use unused numbers first.

Both players continue secretly selecting one remaining number.

The first non-draw round ends the match.

If all remaining numbers are exhausted while still tied, reset both players to a fresh 1–9 hand and continue.

---

## Number Clash Screens

### Intro

```text
NUMBER CLASH

1–9
Each number once
Higher number wins
First to 4 points

[ FIND MATCH ]
```

### Selection

Show:

- Round X of 7
- score
- timer
- large numbers 1–9
- used numbers dimmed
- selected number highlighted
- `LOCK IN`

### Waiting

```text
ALPHA
LOCKED IN ✓

BRAVO
DECIDING...
```

### Reveal

```text
7 VS 4

ALPHA WINS THE ROUND

3 - 1
```

### History

A compact history is useful:

```text
R1  9 vs 3
R2  2 vs 8
R3  7 vs 4
```

Do not turn the page into a large spreadsheet.

### Result

```text
ALPHA WINS

4 - 2

[ PLAY AGAIN ]
[ DUEL MENU ]
```

---

# 5. BID WAR

## Core Concept

Each player begins with:

**20 coins**

The match contains:

**5 auctions**

Prize values are:

```text
1 VP
2 VP
3 VP
4 VP
5 VP
```

Shuffle the five prizes once on the server when the match starts.

Both players use the same prize sequence.

At any point reveal only:

- current prize
- next prize

Do not reveal later prizes.

---

## Bidding

Each player secretly chooses a whole-number bid from:

```text
0
to
their current coin balance
```

Both players lock independently.

After both lock, reveal the bids simultaneously.

Higher bid wins the current prize.

**Both bids are always spent.**

Example:

```text
Prize: 3 VP

Alpha bids 7
Bravo bids 4

Alpha receives 3 VP.

Alpha:
20 → 13 coins

Bravo:
20 → 16 coins
```

Never refund the losing bid.

Unused coins do not become Victory Points.

---

## Tied Auction

If both bids are equal:

- both bids are spent
- nobody receives the current prize
- the current prize value rolls into the next auction

Example:

```text
Current prize = 2 VP
Next prize = 5 VP
Tie

Next auction = 7 VP
```

Only Victory Points roll forward.

---

## Final Auction Tie

If Auction 5 ties, create an Overtime Auction.

For v1:

- the unresolved prize becomes the overtime prize
- both players receive a fresh temporary pool of 5 overtime coins
- each secretly bids 0–5
- higher bid receives the unresolved prize
- if tied again, refresh both overtime pools to 5 and repeat

This avoids distorting the normal five-auction economy.

If all prize points are assigned but overall VP is still tied, run a final 1-VP overtime auction using the same equal temporary coin rule.

---

## Bid War State

Conceptually:

```ts
interface BidWarPlayerState {
  playerId: string;
  coins: number;
  victoryPoints: number;
  lockedBid?: number;
}

interface BidWarPrize {
  baseValue: number;
  currentValue: number;
}
```

The server must reject:

- negative bids
- decimals
- bids above current balance
- duplicate locked bids for the same auction
- actions outside the current phase

---

## Bid Control

Use a large exact numeric control.

Recommended:

```text
[-]      7      [+]

0   2   4   6   ALL IN

[ LOCK BID ]
```

A slider may be supplemental but must not be the only exact input method.

---

## Bid War Screens

### Intro

```text
BID WAR

20 starting coins
5 auctions
Highest bid wins
Both bids are spent

[ FIND MATCH ]
```

### Auction

Show prominently:

```text
AUCTION 2 OF 5

CURRENT PRIZE
3 VP

NEXT PRIZE
5 VP
```

Player panels show public balances and VP.

Opponent's current bid stays hidden.

### Reveal

```text
7 VS 4

ALPHA WINS
+3 VP
```

### Tie

```text
TIED BID

Both players spent 4 coins.

3 VP rolls forward.

NEXT PRIZE
8 VP
```

### Match Result

```text
ALPHA WINS

12 VP - 9 VP

Coins Remaining
6 - 8

[ PLAY AGAIN ]
[ DUEL MENU ]
```

Coins remaining are contextual only and do not affect the winner.

---

# 6. Duel Game Selector

Add the three games to the existing Duel Mode selector.

Keep the current Rock Paper Scissors entry.

Suggested short descriptions:

```text
Rock Paper Scissors
Classic prediction.

Crown Duel
Characters, counters, and one hidden hand rewrite.

Number Clash
Spend your strongest numbers wisely.

Bid War
Risk limited coins for valuable prizes.
```

Keep full rules behind a `How to Play` or `Full Rules` action.

---

# 7. Recommended Components

Reuse existing components first.

Possible shared components:

```text
DuelGameShell
DuelHeader
DuelPlayerPanel
RoundIndicator
DecisionTimer
LockInButton
HiddenOpponentChoice
RoundReveal
RoundResultBanner
MatchResult
RematchControls
RulesDrawer
```

Crown Duel:

```text
CrownCard
CrownHand
CrownCardGuide
RoyalSacrificeButton
RoyalSacrificeModal
SacrificeAnnouncement
```

Number Clash:

```text
NumberCard
NumberHand
NumberHistory
```

Bid War:

```text
PrizeCard
BidControl
CoinBalance
AuctionHistory
PrizeRolloverBanner
```

Do not abstract merely for abstraction's sake. Shared components should correspond to genuinely shared behaviour.

---

# 8. Public vs Private State

The player may know their own:

- hidden current choice
- Crown Duel hand
- Royal Sacrifice details
- Number Clash selection
- Bid War current bid

The opponent may publicly know:

- score
- round
- whether the other player is locked
- whether Royal Sacrifice occurred
- previously revealed Crown Duel cards
- previously revealed Number Clash numbers
- Bid War coin balance
- previous bids and results

The opponent must not receive the exact post-sacrifice Crown Duel hand.

That secrecy is a core rule.

---

# 9. Server Validation

Treat every client action as untrusted.

The server must reject at least:

### Crown Duel

- playing a used card
- playing a sacrificed card
- sacrificing a played card
- sacrificing anything other than exactly two legal unused cards
- transforming one of the two sacrificed cards
- creating a King
- using Royal Sacrifice twice
- locking more than one combat card
- acting in the wrong phase

### Number Clash

- replaying a used number
- choosing outside 1–9
- submitting twice after lock
- acting outside selection phase

### Bid War

- negative bid
- decimal bid
- bid above balance
- duplicate locked bid
- acting outside bidding phase

Clients submit actions, never winners.

Bad:

```json
{ "winner": "alpha" }
```

Good:

```json
{ "action": "play_card", "cardInstanceId": "card_4" }
```

The server resolves outcomes.

---

# 10. Testing

## Crown Duel

Unit-test all 25 ordered card pairings.

Verify:

- same card always draws
- different cards never draw
- King beats Knight, Guard, Assassin
- Peasant beats King
- Knight beats Assassin and Peasant
- Guard beats Knight and Peasant
- Assassin beats Guard and Peasant
- Royal Sacrifice requires exactly two cards
- target is separate from sacrificed cards
- King cannot be created
- duplicates are legal
- sacrifice can only happen once
- public opponent state reveals only that sacrifice occurred

## Number Clash

Verify:

- higher number wins
- same number draws
- used number cannot be replayed
- both numbers are consumed after draw
- winner gains exactly one point
- match ends at four points
- tied normal match reaches Sudden Death

## Bid War

Verify:

- higher bid wins
- both bids are spent
- zero bid is legal
- over-balance bid fails
- ties spend both bids
- tied prize rolls forward correctly
- final-auction tie enters overtime
- highest VP wins
- remaining coins do not change VP

## Multiplayer

Test:

- Alpha submits first
- Bravo submits first
- nearly simultaneous submits
- slow client
- duplicate network requests
- disconnect before reveal
- reconnect after reveal
- timeout
- stale previous-round action
- rematch
- one player leaves

Message arrival order must never change the correct outcome.

---

# 11. Implementation Order

Recommended order:

### Phase 1 — Inspect Existing Duel Mode

Find and understand:

- RPS route/component
- lobby
- room model
- sockets/network handlers
- ready state
- timers
- reconnect logic
- result/rematch flow
- design tokens

Reuse before replacing.

### Phase 2 — Shared Hidden-Action Infrastructure

Create only the minimum shared abstraction necessary to support multiple duel types.

Existing RPS must continue working after refactoring.

### Phase 3 — Number Clash

Implement this first because its rules are smallest and it is ideal for validating hidden action, simultaneous reveal, score updates, and rematch.

### Phase 4 — Crown Duel Base

Implement:

- five card instances
- matchup resolver
- three rounds
- same-card draws
- scoring
- Sudden Death

### Phase 5 — Royal Sacrifice

Add:

- strategy phase
- sacrifice selection
- transformation
- hidden resulting hand
- public sacrifice notification

### Phase 6 — Bid War

Implement:

- prize shuffle
- current/next prize
- coin balances
- hidden bids
- bid spending
- prize rollover
- overtime

### Phase 7 — Polish

Add:

- transitions
- rules drawer
- responsive layouts
- accessibility
- sound hooks
- analytics if the project already has analytics
- error/reconnect states

---

# 12. Performance Requirements

Keep the games lightweight.

Avoid adding:

- Phaser
- Three.js
- PixiJS
- heavy card-game libraries
- separate state-management frameworks
- large looping videos
- huge background images
- duplicate socket infrastructure

Prefer:

- existing components
- CSS transitions
- SVG/icons
- compressed WebP/AVIF character artwork
- one reusable illustration per Crown Duel character

The games should feel rich because of layout and presentation, not because the browser is running a full game engine.

---

# 13. Acceptance Criteria

Implementation is complete when:

## General

- Crown Duel, Number Clash, and Bid War appear in Duel Mode
- existing RPS still works
- two real clients can complete each match
- ping does not determine outcomes
- hidden selections are not leaked
- timers and reconnects do not corrupt state
- all games support rematch
- desktop and mobile layouts work
- no unnecessary heavyweight game dependency is introduced

## Crown Duel

- exactly three normal rounds
- only identical card identities draw
- every different-card pair has one winner
- King defeats Knight, Guard, Assassin
- Peasant defeats King
- Guard defeats Knight
- Knight defeats Assassin
- Assassin defeats Guard
- all three fighters defeat Peasant
- Royal Sacrifice is once per player per match
- exactly two unused cards are sacrificed
- one separate card is transformed
- King cannot be created
- duplicate non-King identities are legal
- opponent is told a sacrifice occurred
- opponent is not told what changed

## Number Clash

- numbers 1–9
- every number usable once
- higher number wins
- equal number draws
- first to four points wins
- up to seven normal rounds
- tied match reaches Sudden Death

## Bid War

- 20 starting coins
- five prizes with values 1–5
- prize order is server-shuffled
- current and next prize are public
- bids remain hidden until both lock
- higher bid wins
- both bids are spent
- tied prize rolls forward
- final tied prize reaches overtime
- highest VP wins
- remaining coins do not add to score

---

# 14. Final Product Intent

The Duel Mode should now offer four mechanically different experiences:

**Rock Paper Scissors** — pure prediction.

**Crown Duel** — prediction, counters, memory, and a once-per-match hidden hand rewrite.

**Number Clash** — resource timing and calculated sacrifice.

**Bid War** — bluffing, economy, and deciding which battles are worth paying for.

They should share one multiplayer shell and one strong visual identity while remaining small, fast, and easy to maintain.

---

# 15. Asset Acquisition & Image Sources

This implementation must not leave Codex guessing where visual assets should come from.

Use the following asset hierarchy:

1. **Existing project assets first**
2. **Provided design-reference mockups**
3. **DiceBear for player avatars**
4. **Kenney for UI/game-interface assets**
5. **Game-icons.net for game symbols**
6. **OpenGameArt / itch.io only when a matching asset is still missing and its individual license has been checked**
7. **Custom generated artwork for the five Crown Duel character portraits if a coherent matching set cannot be found**

Do not scrape Google Images, Pinterest, Dribbble, Behance, ArtStation, random game wikis, commercial games, or other sources where reuse rights are unclear.

## 15.1 Player Avatars — DiceBear

Primary source:

https://www.dicebear.com/

License overview:

https://www.dicebear.com/licenses/

Recommended CC0 styles to inspect:

- Lorelei: https://www.dicebear.com/styles/lorelei/
- Lorelei Neutral: https://www.dicebear.com/styles/lorelei-neutral/
- Notionists: https://www.dicebear.com/styles/notionists/
- Open Peeps: https://www.dicebear.com/styles/open-peeps/
- Pixel Art: https://www.dicebear.com/styles/pixel-art/

Prefer a CC0 style when possible so the project has the simplest licensing requirements.

DiceBear is especially useful because avatars can be deterministic. A stable player ID or username can be used as the seed so every player automatically receives the same avatar on every device without manually storing individual portrait files.

Example:

```html
<img
  src="https://api.dicebear.com/10.x/lorelei/svg?seed=PLAYER_ID"
  alt="Player avatar"
/>
```

Do not use a player's email address directly as the public seed. Prefer an internal non-sensitive stable ID or a hashed/public-safe identifier.

If the application should not depend on a third-party image request at runtime, use the DiceBear JavaScript package or pre-generate/cache the SVGs locally.

## 15.2 UI Panels, Buttons, Frames, Badges — Kenney

Primary source:

https://kenney.nl/assets

Kenney's game assets are CC0/public-domain licensed.

Useful packs:

### UI Pack

https://kenney.nl/assets/ui-pack

Good for:

- buttons
- sliders
- panels
- generic controls
- small interface pieces

### Fantasy UI Borders

https://kenney.nl/assets/fantasy-ui-borders

Good for:

- Crown Duel card frames
- royal borders
- decorative panels
- result frames

Use these selectively. The surrounding product should still look like Relay rather than a completely different medieval UI.

### UI Pack — RPG Expansion

https://kenney.nl/assets/ui-pack-rpg-expansion

Good for:

- additional frames
- fantasy-flavored controls
- ornamental panel details

### Ranks Pack

https://kenney.nl/assets/ranks-pack

Good for:

- rank markers
- medals
- badges
- leaderboard embellishments

### Board Game Info

https://kenney.nl/assets/board-game-info

Good for:

- card/board-game symbols
- small info markers
- rule/help icons

Do not import an entire pack into the production bundle if only five SVG/PNG assets are needed. Copy only required assets into the project's asset directory.

## 15.3 Crowns, Swords, Shields, Coins and Game Symbols — Game-icons.net

Primary source:

https://game-icons.net/

The icons are generally provided under CC BY 3.0 and require attribution.

Useful searches/tags include:

- crown
- king
- knight
- shield
- assassin
- sword
- coin
- treasure
- auction
- cards
- lightning
- trophy

Board/card collection:

https://game-icons.net/tags/board.html

Symbol/emblem collection:

https://game-icons.net/tags/symbol.html

License/about:

https://game-icons.net/about.html

If Game-icons.net assets are used, add a small Credits / Open Source Assets entry in the product or repository such as:

```text
Game icons by Lorc, Delapouite & contributors
https://game-icons.net
Licensed under CC BY 3.0
```

Prefer SVG files so colors can be adapted to Relay's blue, red, purple and gold design tokens.

## 15.4 Crown Duel Character Art

The production game needs a visually coherent five-character set:

```text
king
knight
guard
assassin
peasant
```

The five portraits should look as though they belong to the same game.

Do not combine five unrelated illustrations from different artists/styles merely because each is individually free.

Preferred order:

### Option A — Custom coherent artwork

Use a custom-generated five-character pack following the supplied Crown Duel mockups.

Target characteristics:

- stylized game-card portraits
- not photorealistic
- clean silhouette at small size
- transparent or easily masked background
- consistent lighting and crop
- chest/waist-up compositions
- visually distinct silhouettes
- no text baked into the artwork
- no card frame baked into the artwork
- card frame and labels should be HTML/CSS so they remain responsive

Suggested production filenames:

```text
/public/assets/duel/crown/king.webp
/public/assets/duel/crown/knight.webp
/public/assets/duel/crown/guard.webp
/public/assets/duel/crown/assassin.webp
/public/assets/duel/crown/peasant.webp
```

Generate at a larger source resolution and export web versions around 512–768 px tall unless the existing asset pipeline dictates otherwise.

### Option B — OpenGameArt

https://opengameart.org/

Only use assets after checking the license on the **individual asset page**.

Prefer CC0 when available.

If using CC BY, preserve the author, asset title, URL and license in the project's credits file.

OpenGameArt hosts assets under multiple different licenses. Do not assume that everything on the site shares the same license.

### Option C — itch.io Free Game Assets

https://itch.io/game-assets/free

Use only if the specific pack contains a clear license allowing the intended use.

Every pack is independently licensed. Save a copy of the license/readme alongside the imported assets or record it in `ASSET_LICENSES.md`.

Do not treat the word `free` as meaning public domain.

## 15.5 Number Clash Assets

Number Clash should require almost no raster artwork.

Build the number cards with HTML/CSS.

Use:

- CSS gradients
- border glow
- typography
- tiny SVG icons
- lightning/confetti accents

Do not create nine separate number images.

The numbers should be real text so they remain crisp and accessible.

Potential supporting sources:

- Kenney UI Pack for subtle frame pieces
- Game-icons.net for lightning, crown, trophy and rematch symbols

## 15.6 Bid War Assets

Bid War also should not require large illustration packs.

Build the bidding interface in HTML/CSS.

Use external assets only for:

- coin icon
- treasure chest
- trophy/prize
- small auction/bid symbols

Preferred source order:

1. existing project icon library
2. Kenney
3. Game-icons.net
4. OpenGameArt only if a more illustrative treasure chest is required

Do not use a stock-photo treasure chest.

## 15.7 Background Decoration

The supplied mockups use:

- lightning bolts
- dots/halftones
- small confetti shards
- gradients
- glow
- geometric shapes

These should generally be recreated in CSS or simple inline SVG rather than downloaded as large background images.

Examples:

```css
background:
  radial-gradient(circle at 20% 15%, rgba(125, 59, 255, .20), transparent 32%),
  radial-gradient(circle at 80% 20%, rgba(255, 36, 91, .13), transparent 28%),
  #09031f;
```

This keeps the website light and makes the design responsive.

## 15.8 Supplied Mockups Are References, Not Full-Screen Production Images

The provided PNG mockups must be treated as visual references.

Do **not** place an entire screenshot into the application and put invisible buttons over it.

Codex should translate the mockup into real components:

- player cards
- score panels
- game cards
- buttons
- timers
- modals
- labels
- status panels

Only actual illustrations/icons should become image assets.

## 15.9 Asset Folder Recommendation

Adapt to the existing repository structure, but a reasonable organization is:

```text
public/
└── assets/
    └── duel/
        ├── shared/
        │   ├── icons/
        │   └── decoration/
        ├── crown/
        │   ├── king.webp
        │   ├── knight.webp
        │   ├── guard.webp
        │   ├── assassin.webp
        │   └── peasant.webp
        ├── number-clash/
        └── bid-war/
```

Keep an asset provenance file:

```text
docs/
└── ASSET_LICENSES.md
```

For every third-party asset record:

```text
Asset:
Original author:
Source URL:
License:
Modified:
Used in:
```

## 15.10 Rules for Codex When Searching for Assets

Codex is explicitly allowed to search the internet for a visually better asset **only when the license is clear**.

When Codex finds a candidate:

1. open the original asset page
2. verify the license
3. verify commercial reuse is allowed if this project may be commercial
4. prefer CC0
5. if attribution is required, record it
6. download only the needed file
7. optimize it for the web
8. preserve the source URL in `ASSET_LICENSES.md`
9. never use watermarked preview images
10. never use screenshots from another game as production assets

If an asset's rights are unclear, do not use it.

## 15.11 Recommended Asset Strategy for This Project

For the closest implementation to the mockups while staying lightweight:

**Player avatars**
→ DiceBear, seeded automatically per player.

**Crown Duel character portraits**
→ one custom coherent five-character artwork pack.

**Crown Duel borders and small fantasy ornaments**
→ Kenney CC0, modified to fit Relay.

**Crowns / swords / shields / sacrifice / trophy icons**
→ existing project icon set first; then Game-icons.net if needed.

**Number Clash**
→ almost entirely HTML/CSS; no character/image pack required.

**Bid War**
→ HTML/CSS plus a small coin and treasure-chest SVG/PNG.

**Background effects**
→ CSS and inline SVG.

This prevents the frontend from becoming image-heavy while still getting very close to the supplied mockups.
