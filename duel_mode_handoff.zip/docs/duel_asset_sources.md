# Duel Mode — Asset Source Guide

This file is the short asset-only companion to `duel_mode_implementation_spec.md`.

## Primary Sources

### DiceBear — player avatars
https://www.dicebear.com/
License overview: https://www.dicebear.com/licenses/

Recommended CC0 styles:
- https://www.dicebear.com/styles/lorelei/
- https://www.dicebear.com/styles/lorelei-neutral/
- https://www.dicebear.com/styles/notionists/
- https://www.dicebear.com/styles/open-peeps/
- https://www.dicebear.com/styles/pixel-art/

Use a stable, non-sensitive player identifier as `seed` so avatars are automatically assigned and deterministic.

Example:

```html
<img src="https://api.dicebear.com/10.x/lorelei/svg?seed=PLAYER_ID" alt="Player avatar">
```

### Kenney — UI/game assets
https://kenney.nl/assets/

Useful CC0 packs:
- UI Pack: https://kenney.nl/assets/ui-pack
- Fantasy UI Borders: https://kenney.nl/assets/fantasy-ui-borders
- RPG UI Expansion: https://kenney.nl/assets/ui-pack-rpg-expansion
- Ranks Pack: https://kenney.nl/assets/ranks-pack
- Board Game Info: https://kenney.nl/assets/board-game-info

### Game-icons.net — symbols
https://game-icons.net/
License: CC BY 3.0; attribution required.
About/license: https://game-icons.net/about.html

Useful for crowns, shields, swords, coins, treasure, lightning, trophies, card symbols and sacrifice icons.

### OpenGameArt — fallback character/game art
https://opengameart.org/

Licenses vary per asset. Prefer CC0. Verify every asset page individually.

### itch.io free game assets — secondary fallback
https://itch.io/game-assets/free

Each pack has its own license. `Free` does not automatically mean public domain or attribution-free.

## Recommended Project Mix

- Player avatars: DiceBear
- Crown Duel five character portraits: custom coherent artwork
- Crown Duel UI ornaments: Kenney
- General game symbols: existing icons first, then Game-icons.net
- Number Clash: HTML/CSS + SVG only
- Bid War: HTML/CSS + coin/chest icons
- Backgrounds: CSS gradients + simple SVG decoration

Do not use Google Images, Pinterest, Dribbble, ArtStation, other games' screenshots, or watermarked previews as production assets.

## Asset Provenance

Create `docs/ASSET_LICENSES.md` and record for every third-party asset:

```text
Asset:
Author:
Source:
License:
Modification:
Used in:
```
