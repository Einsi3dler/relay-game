# Duel Mode Handoff

Contents:

- `docs/duel_mode_implementation_spec.md` — full implementation rules and architecture
- `docs/duel_asset_sources.md` — concrete sources for avatars, UI assets, icons and character art
- `references/` — design reference mockups only

The PNG files are **reference images**, not production full-screen assets. Recreate their interface using the existing app's HTML/CSS/components.

Production asset source priority:

1. Existing project assets
2. DiceBear for deterministic player avatars
3. Kenney CC0 UI assets
4. Existing icon library / Game-icons.net
5. Verified OpenGameArt or itch.io assets
6. Custom coherent Crown Duel portraits

See the docs for licensing and implementation details.
